@extends('layout')

@section('content')

    <div class="card shadow border-0 p-4">

        <div class="row align-items-center">

            <div class="col-md-4 text-center">

                <img src="{{ $book->image }}" class="img-fluid rounded shadow" style="
                                                                                    height:350px;
                                                                                    width:250px;
                                                                                    object-fit:cover;
                                                                                ">

            </div>

            <div class="col-md-8">

                <h1 class="fw-bold mb-3">
                    {{ $book->title }}
                </h1>

                <h4 class="text-muted mb-3">
                    {{ $book->author }}
                </h4>

                <p class="mb-4">
                    {{ $book->description }}
                </p>

                <h3 class="text-success mb-3">
                    ₹{{ $book->price }}
                </h3>

                @if($book->availability)

                    <span class="badge bg-success mb-4">
                        Available
                    </span>

                @else

                    <span class="badge bg-danger mb-4">
                        Out Of Stock
                    </span>

                @endif

                <div class="mt-4">

                    <a href="/cart/add/{{ $book->id }}" class="btn btn-primary">
                        Add To Cart
                    </a>

                    <a href="/" class="btn btn-dark">
                        Back To Home
                    </a>

                </div>

            </div>

        </div>

    </div>

@endsection