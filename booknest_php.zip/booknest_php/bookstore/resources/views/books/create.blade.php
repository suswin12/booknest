@extends('layout')

@section('content')

    <div class="card shadow border-0 p-4">

        <h1 class="mb-4 fw-bold">
            Add Book
        </h1>

        <form action="/books" method="POST">

            @csrf

            <div class="mb-3">

                <label class="form-label">
                    Book Title
                </label>

                <input type="text" name="title" class="form-control" placeholder="Enter Book Title" required>

            </div>

            <div class="mb-3">

                <label class="form-label">
                    Author Name
                </label>

                <input type="text" name="author" class="form-control" placeholder="Enter Author Name" required>

            </div>

            <div class="mb-3">

                <label class="form-label">
                    Description
                </label>

                <textarea name="description" class="form-control" rows="4" placeholder="Enter Description"
                    required></textarea>

            </div>

            <div class="mb-3">

                <label class="form-label">
                    Image URL
                </label>

                <input type="text" name="image" class="form-control" placeholder="Paste Image URL" required>

            </div>

            <div class="mb-3">

                <label class="form-label">
                    Price
                </label>

                <input type="number" name="price" class="form-control" placeholder="Enter Price" required>

            </div>

            <div class="mb-4">

                <label class="form-label">
                    Availability
                </label>

                <select name="availability" class="form-control">

                    <option value="1">
                        Available
                    </option>

                    <option value="0">
                        Out Of Stock
                    </option>

                </select>

            </div>

            <button class="btn btn-success">
                Save Book
            </button>

        </form>

    </div>

@endsection