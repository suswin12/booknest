@extends('layout')

@section('content')

    <h1>All Books</h1>

    <table class="table table-bordered mt-4">

        <tr>
            <th>Image</th>
            <th>Title</th>
            <th>Author</th>
            <th>Price</th>
            <th>Actions</th>
        </tr>

        @foreach($books as $book)

            <tr>
                <td>
                    <img src="{{ $book->image }}" width="80">
                </td>

                <td>{{ $book->title }}</td>
                <td>{{ $book->author }}</td>
                <td>₹{{ $book->price }}</td>

                <td>
                    <a href="/books/{{ $book->id }}" class="btn btn-info btn-sm">
                        View
                    </a>

                    <a href="/books/{{ $book->id }}/edit" class="btn btn-warning btn-sm">
                        Edit
                    </a>

                    <form action="/books/{{ $book->id }}" method="POST" class="d-inline">
                        @csrf
                        @method('DELETE')

                        <button class="btn btn-danger btn-sm">
                            Delete
                        </button>
                    </form>
                </td>
            </tr>

        @endforeach

    </table>

@endsection