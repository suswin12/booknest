@extends('layout')

@section('content')

    <h1>Edit Book</h1>

    <form action="/books/{{ $book->id }}" method="POST">

        @csrf
        @method('PUT')

        <input type="text" name="title" value="{{ $book->title }}" class="form-control mb-3">

        <input type="text" name="author" value="{{ $book->author }}" class="form-control mb-3">

        <textarea name="description" class="form-control mb-3">{{ $book->description }}</textarea>

        <input type="text" name="image" value="{{ $book->image }}" class="form-control mb-3">

        <input type="number" name="price" value="{{ $book->price }}" class="form-control mb-3">

        <select name="availability" class="form-control mb-3">

            <option value="1" {{ $book->availability ? 'selected' : '' }}>
                Available
            </option>

            <option value="0" {{ !$book->availability ? 'selected' : '' }}>
                Out Of Stock
            </option>

        </select>

        <button class="btn btn-primary">
            Update Book
        </button>

    </form>

@endsection