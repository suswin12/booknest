@extends('layout')

@section('content')

    <h1 class="fw-bold mb-4">
        My Cart
    </h1>

    @if(session('success'))

        <div class="alert alert-success">

            {{ session('success') }}

        </div>

    @endif

    <div class="row">

        @forelse($cart as $book)

            <div class="col-md-3 mb-4">

                <div class="card shadow border-0 h-100">

                    <img
                    src="{{ $book['image'] }}"
                    class="card-img-top"
                    style="height:300px; object-fit:cover;"
                    >

                    <div class="card-body text-center">

                        <h5 class="fw-bold">
                            {{ $book['title'] }}
                        </h5>

                        <h6 class="text-success">
                            ₹{{ $book['price'] }}
                        </h6>

                    </div>

                </div>

            </div>

        @empty

            <h4>
                Cart is Empty
            </h4>

        @endforelse

    </div>

@endsection