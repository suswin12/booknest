@extends('layout')

@section('content')

<h1 class="mb-4 fw-bold">
    Welcome to BookNest
</h1>

<div class="row">

@foreach($books as $book)

    <div class="col-md-3 mb-4">

        <div class="card shadow border-0 h-100">

            <img
            src="{{ $book->image }}"
            class="card-img-top"
            style="height:300px; object-fit:cover;"
            >

            <div class="card-body text-center d-flex flex-column">

                <h5 class="fw-bold">
                    {{ $book->title }}
                </h5>

                <a
                href="/books/{{ $book->id }}"
                class="btn btn-dark btn-sm mt-3"
                >
                    View Details
                </a>

            </div>

        </div>

    </div>

@endforeach

</div>

<hr class="my-5">

<h3 class="mb-4">
    Google Books API
</h3>

<div class="row">

@foreach($apiBooks as $book)

    <div class="col-md-3 mb-4">

        <div class="card shadow border-0 h-100">

            <img
            src="{{ $book['volumeInfo']['imageLinks']['thumbnail'] ?? '' }}"
            class="card-img-top"
            style="height:300px; object-fit:cover;"
            >

            <div class="card-body text-center">

                <h6>
                    {{ $book['volumeInfo']['title'] ?? 'No Title' }}
                </h6>

            </div>

        </div>

    </div>

@endforeach

</div>

@endsection