@extends('layout')

@section('content')

    <div class="row justify-content-center align-items-center">

        <div class="col-md-5">

            <div class="card shadow border-0 p-4 rounded-4">

                <h1 class="fw-bold text-center mb-4">
                    Login
                </h1>

                @if(session('error'))

                    <div class="alert alert-danger">

                        {{ session('error') }}

                    </div>

                @endif

                <form method="POST" action="/login">

                    @csrf

                    <div class="mb-3">

                        <input type="email" name="email" class="form-control p-3" placeholder="Enter Email" required>

                    </div>

                    <div class="mb-4">

                        <input type="password" name="password" class="form-control p-3" placeholder="Enter Password"
                            required>

                    </div>

                    <button class="btn btn-dark w-100 p-2">
                        Login
                    </button>

                </form>

                <p class="text-center text-muted mt-3 mb-0">
                    Login as User or Admin
                </p>

            </div>

        </div>

    </div>

@endsection