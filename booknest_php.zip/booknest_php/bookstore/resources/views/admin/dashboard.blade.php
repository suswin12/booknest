@extends('layout')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <h1 class="fw-bold">
        Admin Dashboard
    </h1>

    <a href="/books/create" class="btn btn-success">
        + Add Book
    </a>

</div>

<div class="row">

    @foreach($books as $book)

        <div class="col-md-4 mb-4">

            <div class="card shadow border-0 h-100">

                <img
                src="{{ $book->image }}"
                class="card-img-top"
                style="height:300px; object-fit:cover;"
                >

                <div class="card-body d-flex flex-column">

                    <h4 class="fw-bold">
                        {{ $book->title }}
                    </h4>

                    <p class="text-muted mb-1">
                        {{ $book->author }}
                    </p>

                    <h5 class="text-success mb-3">
                        ₹{{ $book->price }}
                    </h5>

                    @if($book->availability)

                        <span class="badge bg-success mb-3">
                            Available
                        </span>

                    @else

                        <span class="badge bg-danger mb-3">
                            Out Of Stock
                        </span>

                    @endif

                    <div class="mt-auto">

                        <a
                        href="/books/{{ $book->id }}"
                        class="btn btn-info btn-sm"
                        >
                            View
                        </a>

                        <a
                        href="/books/{{ $book->id }}/edit"
                        class="btn btn-warning btn-sm"
                        >
                            Edit
                        </a>

                        <form
                        action="/books/{{ $book->id }}"
                        method="POST"
                        class="d-inline"
                        >

                            @csrf
                            @method('DELETE')

                            <button
                            class="btn btn-danger btn-sm"
                            onclick="return confirm('Delete this book?')"
                            >
                                Delete
                            </button>

                        </form>

                    </div>

                </div>

            </div>

        </div>

    @endforeach

</div>

@endsection