<!DOCTYPE html>
<html>

<head>

    <title>BookNest</title>

    <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
    rel="stylesheet"
    >

</head>

<body class="bg-light">

    <nav class="navbar navbar-dark bg-dark py-3">

        <div class="container">

            <a href="/" class="navbar-brand fw-bold fs-4">
                BookNest
            </a>

            <div class="d-flex gap-2">

                <a href="/" class="btn btn-light btn-sm px-3">
                    Home
                </a>

                @if(session('admin') || session('user'))

                    <a href="/logout" class="btn btn-danger btn-sm px-3">
                        Logout
                    </a>

                @else

                    <a href="/login" class="btn btn-dark btn-sm px-3">
                        Login
                    </a>

                @endif

            </div>

        </div>

    </nav>

    <div class="container mt-5">

        @yield('content')

    </div>

</body>

</html>