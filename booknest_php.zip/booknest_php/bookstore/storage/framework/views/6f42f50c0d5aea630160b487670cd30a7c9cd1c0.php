

<?php $__env->startSection('content'); ?>

    <div class="card shadow border-0 p-4">

        <div class="row align-items-center">

            <div class="col-md-4 text-center">

                <img src="<?php echo e($book->image); ?>" class="img-fluid rounded shadow" style="
                                                                                    height:350px;
                                                                                    width:250px;
                                                                                    object-fit:cover;
                                                                                ">

            </div>

            <div class="col-md-8">

                <h1 class="fw-bold mb-3">
                    <?php echo e($book->title); ?>

                </h1>

                <h4 class="text-muted mb-3">
                    <?php echo e($book->author); ?>

                </h4>

                <p class="mb-4">
                    <?php echo e($book->description); ?>

                </p>

                <h3 class="text-success mb-3">
                    ₹<?php echo e($book->price); ?>

                </h3>

                <?php if($book->availability): ?>

                    <span class="badge bg-success mb-4">
                        Available
                    </span>

                <?php else: ?>

                    <span class="badge bg-danger mb-4">
                        Out Of Stock
                    </span>

                <?php endif; ?>

                <div class="mt-4">

                    <a href="/cart/add/<?php echo e($book->id); ?>" class="btn btn-primary">
                        Add To Cart
                    </a>

                    <a href="/" class="btn btn-dark">
                        Back To Home
                    </a>

                </div>

            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\suswi\Documents\GitHub\booknest_php\bookstore\resources\views/books/show.blade.php ENDPATH**/ ?>