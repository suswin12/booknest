

<?php $__env->startSection('content'); ?>

    <div class="row justify-content-center align-items-center">

        <div class="col-md-5">

            <div class="card shadow border-0 p-4 rounded-4">

                <h1 class="fw-bold text-center mb-4">
                    Login
                </h1>

                <?php if(session('error')): ?>

                    <div class="alert alert-danger">

                        <?php echo e(session('error')); ?>


                    </div>

                <?php endif; ?>

                <form method="POST" action="/login">

                    <?php echo csrf_field(); ?>

                    <div class="mb-3">

                        <input type="email" name="email" class="form-control p-3" placeholder="Enter Email" required>

                    </div>

                    <div class="mb-4">

                        <input type="password" name="password" class="form-control p-3" placeholder="Enter Password"
                            required>

                    </div>

                    <button class="btn btn-dark w-100 p-2">
                        Login
                    </button>

                </form>

                <p class="text-center text-muted mt-3 mb-0">
                    Login as User or Admin
                </p>

            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\suswi\Documents\GitHub\booknest_php\bookstore\resources\views/admin/login.blade.php ENDPATH**/ ?>