

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between align-items-center mb-4">

    <h1 class="fw-bold">
        Admin Dashboard
    </h1>

    <a href="/books/create" class="btn btn-success">
        + Add Book
    </a>

</div>

<div class="row">

    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="col-md-4 mb-4">

            <div class="card shadow border-0 h-100">

                <img
                src="<?php echo e($book->image); ?>"
                class="card-img-top"
                style="height:300px; object-fit:cover;"
                >

                <div class="card-body d-flex flex-column">

                    <h4 class="fw-bold">
                        <?php echo e($book->title); ?>

                    </h4>

                    <p class="text-muted mb-1">
                        <?php echo e($book->author); ?>

                    </p>

                    <h5 class="text-success mb-3">
                        ₹<?php echo e($book->price); ?>

                    </h5>

                    <?php if($book->availability): ?>

                        <span class="badge bg-success mb-3">
                            Available
                        </span>

                    <?php else: ?>

                        <span class="badge bg-danger mb-3">
                            Out Of Stock
                        </span>

                    <?php endif; ?>

                    <div class="mt-auto">

                        <a
                        href="/books/<?php echo e($book->id); ?>"
                        class="btn btn-info btn-sm"
                        >
                            View
                        </a>

                        <a
                        href="/books/<?php echo e($book->id); ?>/edit"
                        class="btn btn-warning btn-sm"
                        >
                            Edit
                        </a>

                        <form
                        action="/books/<?php echo e($book->id); ?>"
                        method="POST"
                        class="d-inline"
                        >

                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>

                            <button
                            class="btn btn-danger btn-sm"
                            onclick="return confirm('Delete this book?')"
                            >
                                Delete
                            </button>

                        </form>

                    </div>

                </div>

            </div>

        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\suswi\Documents\GitHub\booknest_php\bookstore\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>