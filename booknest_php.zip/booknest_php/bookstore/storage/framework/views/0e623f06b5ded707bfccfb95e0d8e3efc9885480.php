

<?php $__env->startSection('content'); ?>

    <h1>All Books</h1>

    <table class="table table-bordered mt-4">

        <tr>
            <th>Image</th>
            <th>Title</th>
            <th>Author</th>
            <th>Price</th>
            <th>Actions</th>
        </tr>

        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td>
                    <img src="<?php echo e($book->image); ?>" width="80">
                </td>

                <td><?php echo e($book->title); ?></td>
                <td><?php echo e($book->author); ?></td>
                <td>₹<?php echo e($book->price); ?></td>

                <td>
                    <a href="/books/<?php echo e($book->id); ?>" class="btn btn-info btn-sm">
                        View
                    </a>

                    <a href="/books/<?php echo e($book->id); ?>/edit" class="btn btn-warning btn-sm">
                        Edit
                    </a>

                    <form action="/books/<?php echo e($book->id); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>

                        <button class="btn btn-danger btn-sm">
                            Delete
                        </button>
                    </form>
                </td>
            </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\suswi\Documents\GitHub\booknest_php\bookstore\resources\views/books/index.blade.php ENDPATH**/ ?>