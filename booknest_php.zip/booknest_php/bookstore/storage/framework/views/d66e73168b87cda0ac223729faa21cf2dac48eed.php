

<?php $__env->startSection('content'); ?>

    <h1 class="fw-bold mb-4">
        My Cart
    </h1>

    <?php if(session('success')): ?>

        <div class="alert alert-success">

            <?php echo e(session('success')); ?>


        </div>

    <?php endif; ?>

    <div class="row">

        <?php $__empty_1 = true; $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <div class="col-md-3 mb-4">

                <div class="card shadow border-0 h-100">

                    <img
                    src="<?php echo e($book['image']); ?>"
                    class="card-img-top"
                    style="height:300px; object-fit:cover;"
                    >

                    <div class="card-body text-center">

                        <h5 class="fw-bold">
                            <?php echo e($book['title']); ?>

                        </h5>

                        <h6 class="text-success">
                            ₹<?php echo e($book['price']); ?>

                        </h6>

                    </div>

                </div>

            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <h4>
                Cart is Empty
            </h4>

        <?php endif; ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\suswi\Documents\GitHub\booknest_php\bookstore\resources\views/cart.blade.php ENDPATH**/ ?>