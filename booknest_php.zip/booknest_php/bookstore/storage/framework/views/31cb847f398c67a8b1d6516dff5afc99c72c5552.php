

<?php $__env->startSection('content'); ?>

    <h1>Edit Book</h1>

    <form action="/books/<?php echo e($book->id); ?>" method="POST">

        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <input type="text" name="title" value="<?php echo e($book->title); ?>" class="form-control mb-3">

        <input type="text" name="author" value="<?php echo e($book->author); ?>" class="form-control mb-3">

        <textarea name="description" class="form-control mb-3"><?php echo e($book->description); ?></textarea>

        <input type="text" name="image" value="<?php echo e($book->image); ?>" class="form-control mb-3">

        <input type="number" name="price" value="<?php echo e($book->price); ?>" class="form-control mb-3">

        <select name="availability" class="form-control mb-3">

            <option value="1" <?php echo e($book->availability ? 'selected' : ''); ?>>
                Available
            </option>

            <option value="0" <?php echo e(!$book->availability ? 'selected' : ''); ?>>
                Out Of Stock
            </option>

        </select>

        <button class="btn btn-primary">
            Update Book
        </button>

    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\suswi\Documents\GitHub\booknest_php\bookstore\resources\views/books/edit.blade.php ENDPATH**/ ?>