

<?php $__env->startSection('content'); ?>

<h1 class="mb-4 fw-bold">
    Welcome to BookNest
</h1>

<div class="row">

<?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="col-md-3 mb-4">

        <div class="card shadow border-0 h-100">

            <img
            src="<?php echo e($book->image); ?>"
            class="card-img-top"
            style="height:300px; object-fit:cover;"
            >

            <div class="card-body text-center d-flex flex-column">

                <h5 class="fw-bold">
                    <?php echo e($book->title); ?>

                </h5>

                <a
                href="/books/<?php echo e($book->id); ?>"
                class="btn btn-dark btn-sm mt-3"
                >
                    View Details
                </a>

            </div>

        </div>

    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<hr class="my-5">

<h3 class="mb-4">
    Google Books API
</h3>

<?php if(count($apiBooks) > 0): ?>

<div class="row">

<?php $__currentLoopData = $apiBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="col-md-3 mb-4">

        <div class="card shadow border-0 h-100">

            <img
            src="<?php echo e($book['volumeInfo']['imageLinks']['thumbnail'] ?? 'https://via.placeholder.com/128x180?text=No+Image'); ?>"
            class="card-img-top"
            style="height:300px; object-fit:cover;"
            >

            <div class="card-body text-center">

                <h6>
                    <?php echo e($book['volumeInfo']['title'] ?? 'No Title'); ?>

                </h6>

            </div>

        </div>

    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<?php else: ?>

<div class="alert alert-warning">

    Google Books API data is currently unavailable.

</div>

<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\suswi\Documents\GitHub\booknest_php\bookstore\resources\views/home.blade.php ENDPATH**/ ?>