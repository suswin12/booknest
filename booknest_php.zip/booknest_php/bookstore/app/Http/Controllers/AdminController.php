<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Book;

class AdminController extends Controller
{
    public function login()
    {
        return view('admin.login');
    }

    public function checkLogin(Request $request)
    {
        $email = $request->email;
        $password = $request->password;

        // ADMIN LOGIN
        if (
            $email == 'admin@gmail.com' &&
            $password == 'admin123'
        ) {

            session([
                'admin' => true,
                'user' => false
            ]);

            return redirect('/dashboard');
        }

        // NORMAL USER LOGIN
        session([
            'user' => true,
            'admin' => false
        ]);

        return redirect('/');
    }

    public function dashboard()
    {
        if (!session('admin')) {
            return redirect('/login');
        }

        $books = Book::all();

        return view('admin.dashboard', compact('books'));
    }

    public function logout()
    {
        session()->flush();

        return redirect('/');
    }
}