<?php

namespace App\Http\Controllers;

use App\Models\Book;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class BookController extends Controller
{
    public function home()
    {
        $apiBooks = [];

        try {
            $response = Http::withoutVerifying()
                ->timeout(30)
                ->get('https://www.googleapis.com/books/v1/volumes', [
                    'q' => 'programming',
                    'maxResults' => 8,
                    'key' => env('GOOGLE_BOOKS_API_KEY'),
                ]);

            if ($response->successful()) {
                $apiBooks = $response->json()['items'] ?? [];
            } else {
                \Log::warning('Google Books API failed', [
                    'status' => $response->status(),
                    'body' => $response->body(),
                ]);
            }
        } catch (\Exception $e) {
            \Log::error('Google Books API exception: ' . $e->getMessage());
        }

        $books = Book::latest()->get();

        return view('home', compact('apiBooks', 'books'));
    }

    public function index()
    {
        $books = Book::latest()->get();

        return view('books.index', compact('books'));
    }

    public function create()
    {
        if (!session('admin')) {
            return redirect('/login');
        }

        return view('books.create');
    }

    public function store(Request $request)
    {
        if (!session('admin')) {
            return redirect('/login');
        }

        $request->validate([
            'title' => 'required',
            'author' => 'required',
            'description' => 'required',
            'price' => 'required',
            'image' => 'required',
        ]);

        Book::create($request->all());

        return redirect('/dashboard');
    }

    public function show(Book $book)
    {
        return view('books.show', compact('book'));
    }

    public function edit(Book $book)
    {
        if (!session('admin')) {
            return redirect('/login');
        }

        return view('books.edit', compact('book'));
    }

    public function update(Request $request, Book $book)
    {
        if (!session('admin')) {
            return redirect('/login');
        }

        $book->update($request->all());

        return redirect('/dashboard');
    }

    public function destroy(Book $book)
    {
        if (!session('admin')) {
            return redirect('/login');
        }

        $book->delete();

        return redirect('/dashboard');
    }

    public function addToCart($id)
    {
        // User login check
        if (!session('user') && !session('admin')) {

            return redirect('/login')
                ->with('error', 'Please Login First');
        }

        $book = Book::find($id);

        if (!$book) {
            return redirect('/');
        }

        $cart = session()->get('cart', []);

        $cart[$id] = [
            'id' => $book->id,
            'title' => $book->title,
            'price' => $book->price,
            'image' => $book->image,
        ];

        session()->put('cart', $cart);

        return redirect('/cart')
            ->with('success', 'Book Added To Cart Successfully');
    }

    public function cart()
    {
        $cart = session()->get('cart', []);

        return view('cart', compact('cart'));
    }
}