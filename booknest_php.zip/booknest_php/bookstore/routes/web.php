<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BookController;
use App\Http\Controllers\AdminController;

Route::get('/', [BookController::class, 'home']);

Route::get('/login', [AdminController::class, 'login']);

Route::post('/login', [AdminController::class, 'checkLogin']);

Route::get('/logout', [AdminController::class, 'logout']);

Route::get('/dashboard', [AdminController::class, 'dashboard']);

Route::get('/books/create', [BookController::class, 'create']);

Route::post('/books', [BookController::class, 'store']);

Route::get('/books/{book}/edit', [BookController::class, 'edit']);

Route::put('/books/{book}', [BookController::class, 'update']);

Route::delete('/books/{book}', [BookController::class, 'destroy']);

Route::get('/books/{book}', [BookController::class, 'show']);

Route::get('/cart', [BookController::class, 'cart']);

Route::get('/cart/add/{id}', [BookController::class, 'addToCart']);