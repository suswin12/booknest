# 📚 BookNest — PHP Bookstore Application

BookNest is a simple online bookstore web application built with **Laravel 8** (PHP). It allows users to browse books, view details, add books to a cart, and lets admins manage the book inventory through a dashboard.

---

## 🚀 Features

- **Home Page** — Displays books from the local database along with featured books fetched live from the **Google Books API**
- **Book Listing** — Browse all available books
- **Book Details** — View individual book information
- **Shopping Cart** — Add books to a session-based cart
- **Admin Dashboard** — Add, edit, and delete books (admin only)
- **Login System** — Simple session-based login for admin and normal users

---

## 🛠️ Tech Stack

| Layer | Technology |
|---|---|
| Backend Framework | Laravel 8 |
| Language | PHP 7.3 / 8.0 |
| Database | MySQL |
| Frontend | Blade Templates |
| HTTP Client | Guzzle (for Google Books API) |
| Auth | Session-based (no Laravel Auth package) |

---

## 📁 Project Structure

```
bookstore/
├── app/
│   ├── Http/
│   │   └── Controllers/
│   │       ├── BookController.php    # Book CRUD + Cart logic
│   │       └── AdminController.php   # Login / Logout / Dashboard
│   └── Models/
│       └── Book.php                  # Book Eloquent model
├── database/
│   └── migrations/
│       └── 2026_05_12_..._create_books_table.php
├── resources/
│   └── views/
│       ├── home.blade.php
│       ├── cart.blade.php
│       ├── layout.blade.php
│       ├── books/
│       │   ├── index.blade.php
│       │   ├── show.blade.php
│       │   ├── create.blade.php
│       │   └── edit.blade.php
│       └── admin/
│           ├── login.blade.php
│           └── dashboard.blade.php
└── routes/
    └── web.php
```

---

## ⚙️ Installation & Setup

### Prerequisites

- PHP >= 7.3
- Composer
- MySQL
- Node.js & npm (for frontend assets)

### Steps

1. **Clone or extract the project**
   ```bash
   unzip booknest_php.zip
   cd booknest_php/bookstore
   ```

2. **Install PHP dependencies**
   ```bash
   composer install
   ```

3. **Copy environment file**
   ```bash
   cp .env.example .env
   ```

4. **Configure your database** in `.env`:
   ```env
   DB_CONNECTION=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=booknest
   DB_USERNAME=your_db_user
   DB_PASSWORD=your_db_password
   ```

5. **Generate application key**
   ```bash
   php artisan key:generate
   ```

6. **Run database migrations**
   ```bash
   php artisan migrate
   ```

7. **(Optional) Import sample data**
   ```bash
   mysql -u your_db_user -p booknest < database_export.sql
   ```

8. **Start the development server**
   ```bash
   php artisan serve
   ```

   The app will be available at `http://127.0.0.1:8000`

---

## 🔑 Login Credentials

| Role | Email | Password |
|---|---|---|
| Admin | admin@gmail.com | admin123 |
| Normal User | any email | any password |

> **Note:** The normal user login accepts any credentials — it is not validated against a database. This is intended for demo/development purposes only.

---

## 🗺️ Routes

| Method | URL | Description |
|---|---|---|
| GET | `/` | Home page with Google Books API results |
| GET | `/login` | Login page |
| POST | `/login` | Submit login |
| GET | `/logout` | Logout |
| GET | `/dashboard` | Admin dashboard (admin only) |
| GET | `/books/create` | Add new book form (admin only) |
| POST | `/books` | Save new book (admin only) |
| GET | `/books/{book}` | View book details |
| GET | `/books/{book}/edit` | Edit book form (admin only) |
| PUT | `/books/{book}` | Update book (admin only) |
| DELETE | `/books/{book}` | Delete book (admin only) |
| GET | `/cart` | View cart |
| GET | `/cart/add/{id}` | Add book to cart |

---

## 🗄️ Database Schema

### `books` table

| Column | Type | Description |
|---|---|---|
| id | bigint (PK) | Auto-increment primary key |
| title | string | Book title |
| author | string | Author name |
| description | text | Book description |
| price | integer | Price (in currency units) |
| image | string | Image URL or path |
| availability | boolean | Available for purchase (default: true) |
| created_at | timestamp | — |
| updated_at | timestamp | — |

---

## ⚠️ Known Limitations

- Admin credentials are **hardcoded** in `AdminController.php` — not suitable for production
- Normal user login has **no real authentication** (any input is accepted)
- Cart is **session-based** — it is lost when the session expires
- SSL verification is disabled for the Google Books API call (`withoutVerifying()`)
- No input sanitization for mass assignment in `Book::create($request->all())`

---

## 📄 License

This project uses the [MIT License](https://opensource.org/licenses/MIT) (inherited from the Laravel framework).
